option_PDF1.outline = [
  { title: "Note from the CEO – Captain Wissam Mehyou", dest: 3 },
  { title: "Academy News & Milestones", dest: 4 },
  { title: "Student Spotlight", dest: 9 },
  { title: "Instructor Insights", dest: 12 },
  { title: "Flight Science & Innovation", dest: 13 },
  { title: "Industry Trends & Global Aviation Outlook", dest: 14 },
  { title: "Featured Article – Building Your Career Path", dest: 15 },
  { title: "FlyIAA Course – Type Rating Programs", dest: 16 },
  { title: "Frequently Asked Questions", dest: 18 },
  { title: "Video Feature", dest: 20 },
  { title: "Upcoming Events & Programs", dest: 21 },
  { title: "Resources & Career Opportunities", dest: 22 },
  { title: "Quote of the Month", dest: 23 }
];
