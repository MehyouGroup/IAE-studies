  var option_PDF1 = {
  

source: "IAA Journal (Sep).pdf", //you can change the path and the name of your .pdf file 

 


    hard: "hard", 

	backgroundImage: "assets/background.jpg", 
	backgroundColor: "#fff",  

	soundEnable: true, 
	enableDownload: true, 

	autoEnableOutline: false, 

	direction: PDFF.DIRECTION.LTR, 

	autoEnableOutline: false, 

    zoomRatio: 2, 

    paddingTop: 15,  
    paddingLeft: 15,
    paddingRight: 15, 
    paddingBottom: -10, 

	autoPlayStart: false, 
	autoPlayDuration: 5000, 

  	scrollWheel: true, 

    text: {
            toggleSound: "Sound On/Off",
            toggleOutline: "Table of Contents",
            previousPage: "Previous Page",
            nextPage: "Next Page",
            toggleFullscreen: "Fullscreen",
            zoomIn: "Zoom In",
            zoomOut: "Zoom Out",
            downloadPDFFile: "Download PDF",
        },
	
   allControls: "outline,thumbnail,startPage,altPrev,pageNumber,altNext,endPage,zoomIn,zoomOut,fullScreen,download,sound,play"

 

  };


 
